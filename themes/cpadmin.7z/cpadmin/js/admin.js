
$(function () {
    if($(".errorMsg").length > 0){
        setTimeout(function(){
            $(".errorMsg").slideUp(500, function(){
                $(this).remove();
            });
        }, 7000);
    }
    
    $('[data-toggle="tooltip"]').tooltip();

    $('.dropdown-menu a.dropdown-toggle').on('click mouseenter', function(e) {

        if (!$(this).next().hasClass('show')) {
          $(this).parents('.dropdown-menu').first().find('.show').removeClass('show');
        }
        var $subMenu = $(this).next('.dropdown-menu');
        $subMenu.toggleClass('show');
      
      
        $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
          $('.dropdown-submenu .show').removeClass('show');
        });
      
      
        return false;
      });

      $(".help_view").click(function () {
        $("div#xo-system-help").slideToggle(1000);
        $("help_view").toggle();
        $("help_hide").toggle();
    });

    $(".help_hide").click(function () {
        $("div#xo-system-help").slideToggle(1000);
        $(".help_view").toggle();
        $(".help_hide").toggle();
    });
})